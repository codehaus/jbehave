package net.sf.cotta.io;

/** @noinspection JavaDoc*/
public interface LineProcessor {
  void process(String line);
}
