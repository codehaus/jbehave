package net.sf.cotta.io;

import net.sf.cotta.TIoException;
import net.sf.cotta.TPath;

import java.io.InputStream;
import java.io.OutputStream;

public interface StreamFactory extends InputStreamFactory, OutputStreamFactory {

}
