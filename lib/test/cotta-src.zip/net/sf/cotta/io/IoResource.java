package net.sf.cotta.io;

import java.io.IOException;

/** @noinspection JavaDoc*/
public interface IoResource {
  public void close() throws IOException;
}
