package net.sf.cotta.io;

import net.sf.cotta.TIoException;

import java.io.*;

public class InputManager {
  private IoManager ioManager;

  public InputManager(StreamFactory streamFactory) {
    ioManager = new IoManager(streamFactory);
  }

  public InputStream inputStream() throws TIoException {
    return ioManager.inputStream();
  }

  public Reader reader() throws TIoException {
    return ioManager.reader();
  }

  public BufferedReader bufferedReader() throws TIoException {
    return ioManager.bufferedReader();
  }

  public LineNumberReader lineNumberReader() throws TIoException {
    return ioManager.lineNumberReader();
  }

  public void registerResource(InputStream is) {
    ioManager.registerResource(is);
  }

  public void registerResource(Reader reader) {
    ioManager.registerResource(reader);
  }

  public void registerResource(IoResource ioResource) {
    ioManager.registerResource(ioResource);
  }

  public void open(final InputProcessor processor) throws TIoException {
    ioManager.open(new IoProcessor() {
      public void process(IoManager io) throws IOException {
        processor.process(InputManager.this);
      }
    });
  }
}
