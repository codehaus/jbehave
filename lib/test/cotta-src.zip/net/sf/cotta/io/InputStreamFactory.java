package net.sf.cotta.io;

import net.sf.cotta.TIoException;
import net.sf.cotta.TPath;

import java.io.InputStream;

public interface InputStreamFactory {
  InputStream inputStream() throws TIoException;

  TPath path();
}
