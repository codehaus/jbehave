package net.sf.cotta;

import java.io.IOException;

/** @noinspection JavaDoc*/
public class TIoException extends IOException {
  private TPath path;

  public TIoException(TPath path, String message) {
    this(path, message, null);
  }

  public TIoException(TPath path, String message, IOException cause) {
    super(message + "<" + path + ">");
    this.path = path;
    initCause(cause);
  }

  public TPath getPath() {
    return path;
  }
}
