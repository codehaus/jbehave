package net.sf.cotta.jbehave;

import net.sf.cotta.TDirectory;
import net.sf.cotta.TIoException;
import net.sf.cotta.utils.ClassPathEntryLocator;
import net.sf.cotta.utils.ClassPathEntryProcessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class BehavioursLoader {
  private Class classInClassPathEntry;
  private List classNames;

  public BehavioursLoader(Class classInClassPathEntry) {
    this.classInClassPathEntry = classInClassPathEntry;
  }

  public Class[] loadBehaviours() {
    try {
      new ClassPathEntryLocator(classInClassPathEntry).locateEntry().read(collectNames());
    } catch (TIoException e) {
      throw new RuntimeException(e.getMessage(), e);
    }
    return loadClasses();
  }

  private ClassPathEntryProcessor collectNames() {
    return new ClassPathEntryProcessor() {
      public void process(TDirectory directory) throws TIoException {
        classNames = new BehaviourCollector(directory, "").collectNames();
        Collections.sort(classNames);
      }
    };
  }

  private Class[] loadClasses() {
    List loadedClasses = new ArrayList(classNames.size());
    for (Iterator iterator = classNames.iterator(); iterator.hasNext();) {
      String name = (String) iterator.next();
      Class candidateClass = loadClass(name);
      loadedClasses.add(candidateClass);
    }
    return (Class[]) loadedClasses.toArray(new Class[loadedClasses.size()]);
  }

  private Class loadClass(String name) {
    try {
      return Class.forName(name);
    } catch (ClassNotFoundException e) {
      throw new RuntimeException("Couldn't load class " + name + ":" + e.getMessage(), e);
    }
  }
}
