package net.sf.cotta;

import net.sf.cotta.io.OutputMode;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;

/** @noinspection JavaDoc*/
public interface FileSystem {
  boolean fileExists(TPath path);

  void createFile(TPath path) throws TIoException;

  void deleteFile(TPath path) throws TIoException;

  boolean dirExists(TPath path);

  void createDir(TPath path) throws TIoException;

  TPath[] listDirs(TPath path) throws TIoException;

  TPath[] listFiles(TPath path) throws TIoException;

  InputStream createInputStream(TPath path) throws TIoException;

  OutputStream createOutputStream(TPath path, OutputMode mode) throws TIoException;

  void deleteDirectory(TPath path) throws TIoException;

  void moveFile(TPath source, TPath destination) throws TIoException;

  void moveDirectory(TPath source, TPath destination) throws TIoException;

  String pathString(TPath path);

  long fileLength(TPath path);

  File toJavaFile(TPath path);
}
