package net.sf.cotta.zip;

import net.sf.cotta.*;
import net.sf.cotta.io.OutputMode;
import net.sf.cotta.memory.InMemoryFileSystem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** @noinspection JavaDoc*/
public class ZipFileSystem implements FileSystem, TResource {
  private ZipFile file;
  private InMemoryFileSystem entrySystem = new InMemoryFileSystem();
  private TFileFactory factory = new TFileFactory(entrySystem);

  public ZipFileSystem(File jarFile) throws IOException {
    load(jarFile);
  }

  private void load(File jarFile) throws IOException {
    this.file = new ZipFile(jarFile);
    for (Enumeration enumeration = file.entries(); enumeration.hasMoreElements();) {
      ZipEntry entry = (ZipEntry) enumeration.nextElement();
      String pathString = "/" + entry.getName();
      if (entry.isDirectory()) {
        factory.dir(pathString).ensureExists();
      } else {
        factory.file(pathString).create();
      }
    }
  }

  public boolean fileExists(TPath path) {
    return entrySystem.fileExists(path);
  }

  public boolean dirExists(TPath path) {
    return entrySystem.dirExists(path);
  }

  public TPath[] listDirs(TPath path) {
    return entrySystem.listDirs(path);
  }

  public TPath[] listFiles(TPath path) {
    return entrySystem.listFiles(path);
  }

  public InputStream createInputStream(TPath path) throws TIoException {
    if (!entrySystem.fileExists(path)) {
      throw new TFileNotFoundException(path);
    }
    ZipEntry entry = entry(path);
    try {
      return file.getInputStream(entry);
    } catch (IOException e) {
      throw new TIoException(path, "Error opening entry", e);
    }
  }

  private ZipEntry entry(TPath path) {
    String pathString = path.toPathString();
    if (pathString.startsWith("/")) {
      pathString = pathString.substring(1);
    }
    return file.getEntry(pathString);
  }

  public void createDir(TPath path) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public void createFile(TPath path) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public void deleteFile(TPath path) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public OutputStream createOutputStream(TPath path, OutputMode mode) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public void deleteDirectory(TPath path) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public void moveFile(TPath source, TPath destination) {
    throw new UnsupportedOperationException();
  }

  public void moveDirectory(TPath path, TPath path1) throws TIoException {
    throw new UnsupportedOperationException();
  }

  public String pathString(TPath path) {
    StringBuffer buffer = new StringBuffer(file.getName());
    buffer.append("[").append(path.toPathString()).append("]");
    return buffer.toString();
  }

  public long fileLength(TPath path) {
    return entry(path).getSize();
  }

  public File toJavaFile(TPath path) {
    throw new UnsupportedOperationException("ZipFileSystem");
  }

  public void close() throws TIoException {
    try {
      file.close();
    } catch (IOException e) {
      throw new TIoException(TPath.parse("/"), "Cannot close jar file", e);
    }
  }

  public static FileSystem readOnlyZipFileSystem(File jarFile) throws TIoException {
    ZipFileSystem zipFileSystem;
    try {
      zipFileSystem = new ZipFileSystem(jarFile);
    } catch (IOException e) {
      throw new TIoException(TPath.parse("/"), "Error opening zip file <" + jarFile.getAbsolutePath() + ">", e);
    }
    return ControlledFileSystem.readOnlyFileSystem(zipFileSystem);
  }
}
