package net.sf.cotta;

import net.sf.cotta.io.OutputManager;
import net.sf.cotta.io.OutputProcessor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class TDirectory {
  private FileSystem fileSystem;
  private TPath path;

  public TDirectory(FileSystem fileSystem, TPath path) {
    this.fileSystem = fileSystem;
    this.path = path;
  }

  public boolean exists() {
    return fileSystem.dirExists(path);
  }

  public TDirectory ensureExists() throws TIoException {
    if (!fileSystem.dirExists(path)) {
      fileSystem.createDir(path);
    }
    return this;
  }

  /**
   * Constucts a file given the file name
   *
   * @param name the name of the file
   * @return The file that is under the directory with the name
   * @see #file(TPath)
   */
  public TFile file(String name) {
    return new TFile(fileSystem, path.join(name));
  }

  /**
   * Constructs a file given the relative path
   *
   * @param relativePath The relative path to the current directory
   * @return The file that is of the relative to the current directory
   */
  public TFile file(TPath relativePath) {
    return new TFile(fileSystem, path.join(relativePath));
  }

  /**
   * Constructs a subdirectory given the directory name
   *
   * @param name the name of the subdirectory
   * @return The directory that is under the current directory with the given name
   */
  public TDirectory dir(String name) {
    return new TDirectory(fileSystem, path.join(name));
  }

  /**
   * Constructs a directory given the relative path to the current directory
   *
   * @param relativePath the relative path of the target directory to current directory
   * @return The target directory that is of the given the relative path
   */
  public TDirectory dir(TPath relativePath) {
    return new TDirectory(fileSystem, path.join(relativePath));
  }

  public String name() {
    return path.lastElementName();
  }

  public TDirectory[] listDirs() throws TIoException {
    return listDirs(TDirectoryFilter.ALL);
  }

  public TDirectory[] listDirs(TDirectoryFilter directoryFilter) throws TIoException {
    checkDirectoryExists();
    TPath[] paths = fileSystem.listDirs(this.path);
    List directories = new ArrayList(paths.length);
    for (int i = 0; i < paths.length; i++) {
      TDirectory candidate = new TDirectory(fileSystem, paths[i]);
      if (directoryFilter.accept(candidate)) {
        directories.add(candidate);
      }
    }
    return (TDirectory[]) directories.toArray(new TDirectory[directories.size()]);
  }

  private void checkDirectoryExists() throws TDirectoryNotFoundException {
    if (!fileSystem.dirExists(path)) {
      throw new TDirectoryNotFoundException(path);
    }
  }

  public TFile[] listFiles() throws TIoException {
    return listFiles(TFileFilter.ALL);
  }

  public TFile[] listFiles(TFileFilter fileFilter) throws TIoException {
    checkDirectoryExists();
    TPath[] tPaths = fileSystem.listFiles(path);
    List files = new ArrayList(tPaths.length);
    for (int i = 0; i < tPaths.length; i++) {
      TFile candidate = new TFile(fileSystem, tPaths[i]);
      if (fileFilter.accept(candidate)) {
        files.add(candidate);
      }
    }
    return (TFile[]) files.toArray(new TFile[files.size()]);
  }

  public TDirectory parent() {
    return new TDirectory(fileSystem, path.parent());
  }

  public String toString() {
    return super.toString() + "<" + path.toString() + ">";
  }

  public void delete() throws TIoException {
    fileSystem.deleteDirectory(path);
  }

  public void deleteAll() throws TIoException {
    TDirectory[] subDirectory = listDirs();
    for (int i = 0; i < subDirectory.length; i++) {
      subDirectory[i].deleteAll();
    }

    TFile[] files = listFiles();
    for (int i = 0; i < files.length; i++) {
      files[i].delete();
    }
    delete();
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final TDirectory directory = (TDirectory) o;

    return fileSystem.equals(directory.fileSystem) && path.equals(directory.path);

  }

  public int hashCode() {
    int result;
    result = fileSystem.hashCode();
    result = 29 * result + path.hashCode();
    return result;
  }

  public String path() {
    return fileSystem.pathString(path);
  }

  public void mergeTo(TDirectory target) throws TIoException {
    target.ensureExists();
    copySubDirectories(target);
    copyFiles(target);
  }

  private void copySubDirectories(TDirectory target) throws TIoException {
    TDirectory[] subdirs = listDirs();
    for (int i = 0; i < subdirs.length; i++) {
      TDirectory subdir = subdirs[i];
      subdir.mergeTo(target.dir(subdir.name()));
    }
  }

  private void copyFiles(TDirectory target) throws TIoException {
    TFile[] files = listFiles();
    for (int i = 0; i < files.length; i++) {
      TFile file = files[i];
      file.copyTo(target.file(file.name()));
    }
  }

  public void moveTo(TDirectory target) throws TIoException {
    if (!exists()) {
      throw new TFileNotFoundException(path);
    }
    if (target.exists()) {
      throw new TIoException(target.path, "Destination exists");
    }
    if (fileSystem == target.fileSystem || fileSystem.equals(target.fileSystem)) {
      fileSystem.moveDirectory(path, target.path);
    } else {
      this.mergeTo(target);
      delete();
    }
  }

  public File getJavaFile() {
    return fileSystem.toJavaFile(path);
  }

  public void zipTo(TFile file) throws TIoException {
    file.write(new OutputProcessor() {
      public void process(OutputManager outputManager) throws IOException {
        ZipOutputStream zipStream = new ZipOutputStream(outputManager.outputStream());
        outputManager.registerResource(zipStream);
        addDirEntry(zipStream, "", TDirectory.this);
      }

      private void addDirEntry(ZipOutputStream zipStream, String path, TDirectory directory) throws IOException {
        TFile[] files = directory.listFiles();
        for (int i = 0; i < files.length; i++) {
          addFileEntry(zipStream, path, files[i]);
        }
        TDirectory[] directories = directory.listDirs();
        for (int i = 0; i < directories.length; i++) {
          TDirectory subDirectory = directories[i];
          addDirEntry(zipStream, path + "/" + subDirectory.name(), subDirectory);
        }
        zipStream.putNextEntry(new ZipEntry(path + "/"));
        zipStream.closeEntry();
      }

      private void addFileEntry(ZipOutputStream zipStream, String path, TFile file) throws IOException {
        ZipEntry entry = new ZipEntry(path + file.name());
        zipStream.putNextEntry(entry);
        file.copyTo(zipStream);
        zipStream.closeEntry();
      }
    });
  }
}
