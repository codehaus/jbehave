package net.sf.cotta;

public interface TFileDirectoryFilter extends TFileFilter, TDirectoryFilter {
}
