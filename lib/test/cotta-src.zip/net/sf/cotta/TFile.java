package net.sf.cotta;

import net.sf.cotta.io.*;

import java.io.*;

/** @noinspection JavaDoc*/
public class TFile {
  private TPath path;
  private FileSystem fileSystem;
  private static final int READ_BUFFER_SIZE = 64;

  public TFile(FileSystem fileSystem, TPath path) {
    this.fileSystem = fileSystem;
    this.path = path;
  }

  public boolean exists() {
    return fileSystem.fileExists(path);
  }

  public TFile create() throws TIoException {
    parent().ensureExists();
    fileSystem.createFile(path);
    return this;
  }

  public String name() {
    return path.lastElementName();
  }

  public String extname() {
    String name = name();
    int index = name.lastIndexOf('.');
    return index == -1 ? "" : name.substring(index + 1);
  }

  public String basename() {
    String name = name();
    int index = name.lastIndexOf('.');
    return index == -1 ? name : name.substring(0, index);
  }

  public TDirectory parent() {
    return new TDirectory(fileSystem, path.parent());
  }

  public void delete() throws TIoException {
    fileSystem.deleteFile(path);
  }

  private StreamFactory streamFactory() {
    return new StreamFactory() {
      public InputStream inputStream() throws TIoException {
        return TFile.this.inputStream();
      }

      public OutputStream outputStream(OutputMode mode) throws TIoException {
        return TFile.this.outputStream(mode);
      }

      public TPath path() {
        return path;
      }
    };
  }

  private OutputStream outputStream(OutputMode mode) throws TIoException {
    parent().ensureExists();
    return fileSystem.createOutputStream(path, mode);
  }

  private InputStream inputStream() throws TIoException {
    return fileSystem.createInputStream(path);
  }

  public void copyTo(final TFile target) throws TIoException {
    target.write(new OutputProcessor() {
      public void process(OutputManager outputManager) throws IOException {
        copyTo(outputManager.outputStream());
      }
    });
  }

  public void copyTo(final OutputStream outputStream) throws TIoException {
    read(new InputProcessor() {
      public void process(InputManager inputManager) throws IOException {
        copy(inputManager.inputStream(), outputStream);
      }
    });
  }

  private void copy(InputStream is, OutputStream os) throws IOException {
    byte[] buffer = new byte[256];
    int read = is.read(buffer, 0, buffer.length);
    while (read > -1) {
      os.write(buffer, 0, read);
      read = is.read(buffer, 0, buffer.length);
    }
  }

  public void moveTo(TFile destination) throws TIoException {
    if (!exists()) {
      throw new TFileNotFoundException(path);
    }
    if (destination.exists()) {
      throw new TIoException(destination.path, "Destination exists");
    }
    if (fileSystem == destination.fileSystem || fileSystem.equals(destination.fileSystem)) {
      fileSystem.moveFile(this.path, destination.path);
    } else {
      this.copyTo(destination);
      delete();
    }
  }

  public String path() {
    return fileSystem.pathString(path);
  }

  public long length() {
    return fileSystem.fileLength(path);
  }

  public TFile ensureExists() throws TIoException {
    if (!exists()) {
      create();
    }
    return this;
  }

  public IoFactory io() {
    return new IoFactory(streamFactory());
  }

  public void open(IoProcessor processor) throws TIoException {
    new IoManager(streamFactory()).open(processor);
  }

  public void read(final InputProcessor processor) throws TIoException {
    new InputManager(streamFactory()).open(processor);
  }

  public void append(final OutputProcessor processor) throws TIoException {
    new OutputManager(streamFactory(), OutputMode.APPEND).open(processor);
  }

  public void write(final OutputProcessor processor) throws TIoException {
    new OutputManager(streamFactory(), OutputMode.OVERWRITE).open(processor);
  }

  public void open(final LineProcessor lineProcessor) throws TIoException {
    open(new IoProcessor() {
      public void process(IoManager io) throws IOException {
        BufferedReader reader = io.bufferedReader();
        String line = reader.readLine();
        while (line != null) {
          lineProcessor.process(line);
          line = reader.readLine();
        }
      }
    });
  }

  public String load() throws TIoException {
    final StringBuffer buffer = new StringBuffer();
    open(new IoProcessor() {
      public void process(IoManager io) throws IOException {
        loadContent(buffer, io.reader());
      }
    });
    return buffer.toString();
  }

  private void loadContent(StringBuffer content, Reader reader) throws IOException {
    char[] buffer = new char[READ_BUFFER_SIZE];
    int read = 0;
    while (read != -1) {
      content.append(buffer, 0, read);
      read = reader.read(buffer, 0, buffer.length);
    }
  }

  public void save(final String content) throws TIoException {
    open(new IoProcessor() {
      public void process(IoManager io) throws IOException {
        Writer writer = io.writer(OutputMode.OVERWRITE);
        writer.write(content);
        writer.flush();
      }
    });
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final TFile file = (TFile) o;

    return fileSystem.equals(file.fileSystem) && path.equals(file.path);
  }

  public int hashCode() {
    int result;
    result = path.hashCode();
    result = 29 * result + fileSystem.hashCode();
    return result;
  }

  /**
   * Converts the TFile instance to java.io.File.  This is used to integrate with the system
   * that uses java.io.File
   * @return The java.io.File instance of the current file
   * @throws RuntimeException if the underlying file system is not a normal file system.
   */
  public File toJavaFile() {
    return fileSystem.toJavaFile(path);
  }

  public String toString() {
    return "TFile:" + path();
  }
}