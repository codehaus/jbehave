package net.sf.cotta.memory;

import net.sf.cotta.ByteArrayIndexOutOfBoundsException;

public class ByteArrayBuffer {
  private byte[] buffer;
  private int size = 0;
  private static final int MAGIC_NUMBER = 16;

  public ByteArrayBuffer(byte[] content) {
    this.buffer = new byte[content.length + MAGIC_NUMBER];
    System.arraycopy(content, 0, buffer, 0, content.length);
    size = content.length;
  }

  public ByteArrayBuffer() {
    this(MAGIC_NUMBER);
  }

  public ByteArrayBuffer(int initialCapacity) {
    buffer = new byte[initialCapacity];
  }

  public byte[] toByteArray() {
    byte[] result = new byte[size];
    System.arraycopy(buffer, 0, result, 0, size);
    return result;
  }

  public ByteArrayBuffer append(byte b) {
    int newSize = size + 1;
    if (newSize > buffer.length) {
      encreaseCapacity();
    }
    buffer[size] = b;
    size++;
    return this;
  }

  private void encreaseCapacity() {
    byte[] newBuffer = new byte[buffer.length + MAGIC_NUMBER];
    System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
    buffer = newBuffer;
  }

  public byte byteAt(int position) {
    if (position < 0 || position >= size) {
      throw new ByteArrayIndexOutOfBoundsException(position, size);
    }
    return buffer[position];
  }

  public int size() {
    return size;
  }
}
