package net.sf.cotta;

import java.io.InputStream;
import java.io.OutputStream;

public interface FileSystem {
  boolean fileExists(TPath path);

  void createFile(TPath path) throws TIoException;

  void deleteFile(TPath path) throws TIoException;

  boolean dirExists(TPath path);

  void createDir(TPath path) throws TIoException;

  TPath[] listDirs(TPath path) throws TIoException;

  TPath[] listFiles(TPath path) throws TIoException;

  InputStream createInputStream(TPath path) throws TIoException;

  OutputStream createOutputStream(TPath path, FileIo.Mode mode) throws TIoException;

  void deleteDirectory(TPath path) throws TIoException;

  void moveFile(TPath source, TPath destination) throws TIoException;

  String pathString(TPath path);

  long fileLength(TPath path);
}
