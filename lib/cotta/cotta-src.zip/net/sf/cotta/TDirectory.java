package net.sf.cotta;

public class TDirectory {
  private FileSystem fileSystem;
  private TPath path;

  public TDirectory(FileSystem fileSystem, TPath path) {
    this.fileSystem = fileSystem;
    this.path = path;
  }

  public boolean exists() {
    return fileSystem.dirExists(path);
  }

  public TDirectory ensureExists() throws TIoException {
    if (!fileSystem.dirExists(path)) {
      fileSystem.createDir(path);
    }
    return this;
  }

  public TFile file(String name) {
    return new TFile(fileSystem, path.join(name));
  }

  public TDirectory dir(String name) {
    return new TDirectory(fileSystem, path.join(name));
  }

  public String name() {
    return path.lastElementName();
  }

  public TDirectory[] listDirs() throws TIoException {
    checkDirectoryExists();
    TPath[] paths = fileSystem.listDirs(this.path);
    TDirectory[] directories = new TDirectory[paths.length];
    for (int i = 0; i < paths.length; i++) {
      directories[i] = new TDirectory(fileSystem, paths[i]);
    }
    return directories;
  }

  private void checkDirectoryExists() throws TDirectoryNotFoundException {
    if (!fileSystem.dirExists(path)) {
      throw new TDirectoryNotFoundException(path);
    }
  }

  public TFile[] listFiles() throws TIoException {
    checkDirectoryExists();
    TPath[] tPaths = fileSystem.listFiles(path);
    TFile[] files = new TFile[tPaths.length];
    for (int i = 0; i < tPaths.length; i++) {
      files[i] = new TFile(fileSystem, tPaths[i]);
    }
    return files;
  }

  /**
   *
   * @return
   * @deprecated use path for system dependent path string
   */
  public String toPathString() {
    return path();
  }

  public TDirectory parent() {
    return new TDirectory(fileSystem, path.parent());
  }

  public String toString() {
    return super.toString() + "<" + path.toString() + ">";
  }

  public void delete() throws TIoException {
    fileSystem.deleteDirectory(path);
  }

  public void deleteAll() throws TIoException {
    TDirectory[] subDirectory = listDirs();
    for (int i = 0; i < subDirectory.length; i++) {
      subDirectory[i].deleteAll();
    }

    TFile[] files = listFiles();
    for (int i = 0; i < files.length; i++) {
      files[i].delete();
    }
    delete();
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final TDirectory directory = (TDirectory) o;

    if (!fileSystem.equals(directory.fileSystem)) return false;
    return path.equals(directory.path);

  }

  public int hashCode() {
    int result;
    result = fileSystem.hashCode();
    result = 29 * result + path.hashCode();
    return result;
  }

  public String path() {
      return fileSystem.pathString(path);
  }
}
