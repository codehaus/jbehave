package net.sf.cotta;

import net.sf.cotta.physical.PhysicalFileSystem;

public class TFileFactory {
  private FileSystem fileSystem;

  public TFileFactory() {
    this(new PhysicalFileSystem());
  }

  public TFileFactory(FileSystem fileSystem) {
    this.fileSystem = fileSystem;
  }

  public TFile file(String path) {
    return new TFile(fileSystem, TPath.parse(path));
  }

  public TDirectory dir(String pathString) {
    return new TDirectory(fileSystem, TPath.parse(pathString));
  }
}
