package net.sf.cotta.zip;

import net.sf.cotta.*;
import net.sf.cotta.memory.InMemoryFileSystem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipFileSystem implements FileSystem {
  private ZipFile file;
  private InMemoryFileSystem entrySystem = new InMemoryFileSystem();
  private TFileFactory factory = new TFileFactory(entrySystem);

  private ZipFileSystem(File jarFile) throws IOException {
    load(jarFile);
  }

  private void load(File jarFile) throws IOException {
    this.file = new ZipFile(jarFile);
    for (Enumeration enumeration = file.entries(); enumeration.hasMoreElements();) {
      ZipEntry entry = (ZipEntry) enumeration.nextElement();
      String pathString = "/" + entry.getName();
      if (entry.isDirectory()) {
        factory.dir(pathString).ensureExists();
      } else {
        factory.file(pathString).create();
      }
    }
  }

  public boolean fileExists(TPath path) {
    return entrySystem.fileExists(path);
  }

  public boolean dirExists(TPath path) {
    return entrySystem.dirExists(path);
  }

  public TPath[] listDirs(TPath path) {
    return entrySystem.listDirs(path);
  }

  public TPath[] listFiles(TPath path) {
    return entrySystem.listFiles(path);
  }

  public InputStream createInputStream(TPath path) throws TIoException {
    if (!entrySystem.fileExists(path)) {
      throw new TFileNotFoundException(path);
    }
    ZipEntry entry = entry(path);
    try {
      return file.getInputStream(entry);
    } catch (IOException e) {
      throw new TIoException(path, "Error opening entry", e);
    }
  }

  private ZipEntry entry(TPath path) {
    String pathString = path.toPathString();
    if (pathString.startsWith("/")) {
      pathString = pathString.substring(1);
    }
    ZipEntry entry = file.getEntry(pathString);
    return entry;
  }

  public void createDir(TPath path) throws TIoException {
  }

  public void createFile(TPath path) throws TIoException {
  }

  public void deleteFile(TPath path) throws TIoException {
  }

  public OutputStream createOutputStream(TPath path, FileIo.Mode mode) throws TIoException {
    return null;
  }

  public void deleteDirectory(TPath path) throws TIoException {
  }

  public void moveFile(TPath source, TPath destination) {
  }

  public String pathString(TPath path) {
    StringBuffer buffer = new StringBuffer(file.getName());
    buffer.append("[").append(path.toPathString()).append("]");
    return buffer.toString() ;
  }

  public long fileLength(TPath path) {
    return entry(path).getSize();
  }


  public static FileSystem readOnlyZipFileSystem(File jarFile) throws IOException {
    ZipFileSystem zipFileSystem = new ZipFileSystem(jarFile);
    return ControledFileSystem.readOnlyFileSystem(zipFileSystem);
  }
}
