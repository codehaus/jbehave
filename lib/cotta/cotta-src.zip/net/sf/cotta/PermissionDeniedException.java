package net.sf.cotta;

public class PermissionDeniedException extends TIoException {

  public PermissionDeniedException(TPath path, String message) {
    super(path, message);
  }
}
