package net.sf.cotta;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

/** @noinspection JavaDoc*/
public class TPath {
  private TPath parent;
  private String[] elements;
  private static final String WINDOWS_SEPERATOR_PATTERN = "\\\\";
  private static final String NATIVE_SEPERATOR = "/";

  private TPath(String[] elements) {
    this.elements = elements;
  }

  public String lastElementName() {
    return elements[elements.length - 1];
  }

  public TPath parent() {
    if (elements.length == 1) {
      return null;
    }
    if (parent == null) {
      String[] newElements = new String[elements.length - 1];
      System.arraycopy(elements, 0, newElements, 0, elements.length - 1);
      parent = new TPath(newElements);
    }
    return parent;
  }

  public TPath join(String name) {
    String[] newElements = new String[elements.length + 1];
    System.arraycopy(elements, 0, newElements, 0, elements.length);
    newElements[elements.length] = name;
    return new TPath(newElements);
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final TPath tPath = (TPath) o;

    return Arrays.equals(elements, tPath.elements);
  }

  public int hashCode() {
    int result = 0;
    for (int i = 0; i < elements.length; i++) {
      String element = elements[i];
      result = 29 * result + element.hashCode();
    }
    return result;
  }

  public String toString() {
    return toPathString();
  }

  public static TPath parse(String pathString) {
    if (pathString == null) {
      throw new IllegalArgumentException("null path string is not allowed");
    }
    return new TPath(convertToElementArray(pathString.replaceAll(WINDOWS_SEPERATOR_PATTERN, NATIVE_SEPERATOR)));
  }

  private static String[] convertToElementArray(String pathString) {
    boolean identifiedAsReferencedByRoot = false;
    List list = new ArrayList();
    if (pathString.startsWith("/")) {
      list.add("");
      identifiedAsReferencedByRoot = true;
    }
    for (StringTokenizer tokenizer = new StringTokenizer(pathString, NATIVE_SEPERATOR); tokenizer.hasMoreTokens();) {
      list.add(tokenizer.nextToken());
    }
    if (!identifiedAsReferencedByRoot && !isTopElementADrivePath(list) && !isTopElementWorkingDirectory(list)) {
      list.add(0, ".");
    }
    return (String[]) list.toArray(new String[list.size()]);
  }

  private static boolean isTopElementWorkingDirectory(List list) {
    String top = (String) list.get(0);
    return top.equals(".");
  }

  private static boolean isTopElementADrivePath(List list) {
    String top = (String) list.get(0);
    return top.matches("[A-Z|a-z]:");
  }

  public String toPathString() {
    return toPathStringImpl(NATIVE_SEPERATOR);
  }

  public String toSystemPathString() {
    return toPathStringImpl(File.separator);
  }

  private String toPathStringImpl(String seperator) {
    StringBuffer buffer = new StringBuffer();
    for (int i = 0; i < elements.length; i++) {
      String element = elements[i];
      buffer.append(element).append(seperator);
    }
    if (buffer.length() > 1) {
      buffer.delete(buffer.length() - 1, buffer.length());
    }
    return buffer.toString();
  }

  public boolean isChildOf(TPath path) {
    if (elements.length <= path.elements.length) {
      return false;
    }
    boolean isChild = true;
    for (int i = 0; i < path.elements.length; i++) {
      String element = elements[i];
      if (!element.equals(path.elements[i])) {
        isChild = false;
        break;
      }
    }
    return isChild;
  }
}
