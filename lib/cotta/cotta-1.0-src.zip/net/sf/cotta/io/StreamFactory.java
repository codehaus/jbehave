package net.sf.cotta.io;

import net.sf.cotta.TIoException;
import net.sf.cotta.TPath;

import java.io.InputStream;
import java.io.OutputStream;

/** @noinspection JavaDoc*/
public interface StreamFactory {
  InputStream inputStream() throws TIoException;

  OutputStream outputStream(OutputMode mode) throws TIoException;

  TPath path();
}
