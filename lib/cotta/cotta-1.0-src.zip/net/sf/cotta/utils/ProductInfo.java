package net.sf.cotta.utils;

import net.sf.cotta.TDirectory;
import net.sf.cotta.TIoException;
import net.sf.cotta.TPath;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

/** @noinspection JavaDoc*/
public class ProductInfo {
  private ClassPath path;
  private Manifest manifest;
  private static final String IMPLEMENTATION_TITLE = "Implementation-Title";
  private static final String IMPLEMENTATION_VENDOR = "Implementation-Vendor";
  private static final String IMPLEMENTATION_VERSION = "Implementation-Version";
  private static final String IMPLEMENTATION_BUILD = "Implementation-Build";

  public ProductInfo(ClassPath path) throws TIoException {
    this.path = path;
    loadManifest();
  }

  private void loadManifest() throws TIoException {
    InputStream is = null;
    boolean loadingPassed = false;
    try {
      TDirectory pathRoot = path.asDirectory();
      is = pathRoot.dir("META-INF").file("MANIFEST.MF").io().inputStream();
      manifest = new Manifest(is);
      loadingPassed = true;
    } catch (IOException e) {
      throw new TIoException(tpath(), "Error reading manifest", e);
    } finally {
      closeResource(!loadingPassed, is, path);
    }
  }

  private TPath tpath() {
    return TPath.parse(loadedPath().path());
  }

  private void closeResource(boolean reportError, InputStream is, ClassPath path) throws TIoException {
    try {
      if (is != null) {
        is.close();
      }
      path.closeResource();
    } catch (IOException e) {
      if (reportError) {
        throw new TIoException(tpath(), "Error closing InputStream", e);
      }
    }
  }

  public void info(PrintStream out) {
    out.println("Loaded from " + path.path());
    out.println("Vendor: " + vendor());
    out.println("Title: " + title());
    out.println("URL: " + url());
    version().info(out);
  }

  public ClassPath loadedPath() {
    return path;
  }

  public String vendor() {
    return mainAttributeValue(IMPLEMENTATION_VENDOR);
  }

  public String title() {
    return mainAttributeValue(IMPLEMENTATION_TITLE);
  }

  public VersionNumber version() {
    return new VersionNumber(
        mainAttributeValue(IMPLEMENTATION_VERSION),
        mainAttributeValue(IMPLEMENTATION_BUILD));
  }

  public String url() {
    return mainAttributeValue("Implementation-URL");
  }

  public static ProductInfo forClass(Class aClass) throws TIoException {
    ClassPath path = new ClassPathLocator(aClass).locate();
    return new ProductInfo(path);
  }

  public String mainAttributeValue(String attributeName) {
    return manifest.getMainAttributes().getValue(attributeName);
  }

  public String otherAttributeValue(String section, String attributeName) {
    Attributes attributes = manifest.getAttributes(section);
    return attributes == null ? null : attributes.getValue(attributeName);
  }

}
