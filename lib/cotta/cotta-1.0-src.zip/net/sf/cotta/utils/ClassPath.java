package net.sf.cotta.utils;

import net.sf.cotta.*;
import net.sf.cotta.zip.ZipFileSystem;

import java.io.File;
import java.io.IOException;

/** @noinspection JavaDoc*/
public class ClassPath {
  private ClassPathType type;
  private TDirectory directory;
  private TFile file;
  private TResource resource = TResource.NULL;
  private TDirectory cachedJarDirecotry;

  public ClassPath(TDirectory directory) {
    this.directory = directory;
    type = ClassPathType.DIRECTORY;
  }

  public ClassPath(TFile file) {
    this.file = file;
    type = ClassPathType.FILE;
  }

  public ClassPathType type() {
    return type;
  }

  public TDirectory asDirectory() throws TIoException {
    if (ClassPathType.DIRECTORY.equals(type)) {
      return directory;
    }
    return convertToJarRoot();
  }

  private TDirectory convertToJarRoot() throws TIoException {
    if (cachedJarDirecotry == null) {
      File jarFile = new File(file.path());
      ZipFileSystem fileSystem;
      try {
        fileSystem = new ZipFileSystem(jarFile);
      } catch (IOException e) {
        throw new TIoException(TPath.parse(file.path()), "Error opening zip file <" + jarFile.getAbsolutePath() + ">", e);
      }
      resource = fileSystem;
      cachedJarDirecotry = new TFileFactory(fileSystem).dir("/");
    }
    return cachedJarDirecotry;
  }

  public void closeResource() throws TIoException {
    resource.close();
    cachedJarDirecotry = null;
    resource = TResource.NULL;
  }

  public String path() {
    return ClassPathType.DIRECTORY.equals(type) ? directory.path() : file.path();
  }
}
