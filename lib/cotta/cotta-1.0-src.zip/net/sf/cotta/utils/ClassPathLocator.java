package net.sf.cotta.utils;

import net.sf.cotta.TDirectory;
import net.sf.cotta.TFile;
import net.sf.cotta.TFileFactory;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.StringTokenizer;

/** @noinspection JavaDoc*/
public class ClassPathLocator {
  private Class clazz;

  public ClassPathLocator(Class clazz) {
    this.clazz = clazz;
  }

  public ClassPath locate() {
    URL url = getClass().getResource(resourcePathToClassFile());
    if ("jar".equalsIgnoreCase(url.getProtocol())) {
      return new ClassPath(getJarFileOnClassPath(url));
    } else {
      return new ClassPath(goToClassPathRootDirectory(url));
    }
  }

  private TDirectory goToClassPathRootDirectory(URL url) {
    TFile classFile = getClassFile(url);
    int level = new StringTokenizer(clazz.getName(), ".").countTokens();
    TDirectory directory = classFile.parent();
    for (int i = 0; i < level - 1; i++) {
      directory = directory.parent();
    }
    return directory;
  }

  private String resourcePathToClassFile() {
    return "/" + clazz.getName().replace('.', '/') + ".class";
  }

  private TFile getJarFileOnClassPath(URL url) {
    String file = url.getFile();
    int index = file.indexOf("!");
    if (index == -1) {
      throw new IllegalArgumentException(url.toExternalForm() + " does not have '!' for a Jar URL");
    }
    File fileObject = fromUri(file.substring(0, index));
    return new TFileFactory().file(fileObject.getAbsolutePath());
  }

  private File fromUri(String fileUri) {
    try {
       return new File(new URI(fileUri));
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't locate jar file:" + fileUri, e);
    }
  }

  private TFile getClassFile(URL url) {
    try {
      File file = new File(new URI(url.toExternalForm()));
      return new TFileFactory().file(file.getAbsolutePath());
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't convert URL to File:" + url, e);
    }
  }
}
