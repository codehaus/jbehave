package net.sf.cotta;

public class TDirectoryNotFoundException extends TIoException {

  public TDirectoryNotFoundException(TPath path) {
    super(path, "");
  }

}
