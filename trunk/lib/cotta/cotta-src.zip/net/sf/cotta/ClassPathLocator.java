package net.sf.cotta;

import net.sf.cotta.zip.ZipFileSystem;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.StringTokenizer;

public class ClassPathLocator {
  public static final Resource NULL = new Resource() {
    public void close() {
    }
  };

  private Class clazz;
  private Resource resource = NULL;

  public ClassPathLocator(Class clazz) {
    this.clazz = clazz;
  }

  public TDirectory locateClassPathRoot() {
    URL url = getClass().getResource(resourcePathToClassFile());
    if ("jar".equalsIgnoreCase(url.getProtocol())) {
      return getJarRoot(url);
    } else {
      TFile classFile = getClassFile(url);
      int level = new StringTokenizer(clazz.getName(), ".").countTokens();
      TDirectory directory = classFile.parent();
      for (int i = 0; i < level - 1; i++) {
        directory = directory.parent();
      }
      return directory;
    }
  }

  public void closeResource() throws TIoException {
    resource.close();
  }

  private String resourcePathToClassFile() {
    return "/" + clazz.getName().replace('.', '/') + ".class";
  }

  private TDirectory getJarRoot(URL url) {
    String file = url.getFile();
    int index = file.indexOf("!");
    if (index == -1) {
      throw new IllegalArgumentException(url.toExternalForm() + " does not have '!' for a Jar URL");
    }
    File jarFile;
    try {
      jarFile = new File(new URI(file.substring(0, index)));
      ZipFileSystem zipFileSystem = new ZipFileSystem(jarFile);
      resource = zipFileSystem;
      return new TFileFactory(ControledFileSystem.readOnlyFileSystem(zipFileSystem)).dir("/");
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't convert url to jar file");
    } catch (IOException e) {
      throw new RuntimeException("Coun't read jar file: " + url);
    }
  }

  private TFile getClassFile(URL url) {
    try {
      File file = new File(new URI(url.toExternalForm()));
      return new TFileFactory().file(file.getAbsolutePath());
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't convert URL to File:" + url, e);
    }
  }
}
