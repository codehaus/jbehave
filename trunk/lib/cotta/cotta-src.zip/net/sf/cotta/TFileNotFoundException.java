package net.sf.cotta;

public class TFileNotFoundException extends TIoException {
  public TFileNotFoundException(TPath path) {
    super(path, "");
  }

}
