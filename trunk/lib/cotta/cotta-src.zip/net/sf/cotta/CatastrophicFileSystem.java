package net.sf.cotta;

import net.sf.cotta.memory.InMemoryFileSystem;

import java.util.HashSet;
import java.util.Set;

public class CatastrophicFileSystem extends ControledFileSystem {

  public CatastrophicFileSystem() {
    super(new InMemoryFileSystem(), new CatastrophicController());
  }

  public void diskFull() {
    ((CatastrophicController) controller).diskFull();
  }

  public void lockFile(TPath path) {
    ((CatastrophicController) controller).lockFile(path);
  }

  public void unLockFile(TPath path) {
    ((CatastrophicController) controller).unLockFile(path);
  }

  public void diskErrorFor(TPath path) {
    ((CatastrophicController) controller).diskError(path);
  }

  private static class CatastrophicController implements Controller {
    private boolean diskFull;
    private Set fileLock = new HashSet();
    private Set readError = new HashSet();

    public void writeOperationControl(TPath path) throws TIoException {
      if (diskFull) {
        throw new TIoException(path, "Disk is full");
      }
      if (fileLock.contains(path)) {
        throw new TIoException(path, "File locked");
      }
    }

    public void readOperationControl(TPath path) throws TIoException {
      if (readError.contains(path)) {
        throw new TIoException(path, "Disk Error");
      }
    }

    public void diskFull() {
      diskFull = true;
    }

    public void lockFile(TPath path) {
      fileLock.add(path);
    }

    public void unLockFile(TPath path) {
      fileLock.remove(path);
    }

    public void diskError(TPath path) {
      readError.add(path);
    }
  }
}
