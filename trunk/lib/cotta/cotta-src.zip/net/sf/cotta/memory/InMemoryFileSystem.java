package net.sf.cotta.memory;

import net.sf.cotta.*;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class InMemoryFileSystem implements FileSystem {
  private Map createDirs = new HashMap();
  private Map createFiles = new HashMap();

  public boolean fileExists(TPath path) {
    return createFiles.containsKey(path);
  }

  public void createFile(TPath path) throws TIoException {
    if (!dirExists(path.parent())) {
      throw new TIoException(path, "Parent not created");
    }
    getChildren(path.parent(), createDirs).addFile(path);
    createFileInSystem(path).setContent("");
  }

  public void createDir(TPath path) throws TIoException {
    if (dirExists(path)) {
      throw new IllegalArgumentException(path.toPathString() + " already exists");
    }
    if (fileExists(path)) {
      throw new TIoException(path, "already exists as a file");
    }
    createDirImpl(path);
    ensureParentExists(path).addDir(path);
  }

  public void deleteFile(TPath path) throws TFileNotFoundException {
    if (!createFiles.containsKey(path)) {
      throw new TFileNotFoundException(path);
    }
    createFiles.remove(path);
    getChildren(path.parent(), createDirs).removeFile(path);
  }

  public boolean dirExists(TPath path) {
    if (createDirs.containsKey(path)) {
      return true;
    }
    if (path.parent() == null) {
      createDirImpl(path);
      return true;
    }
    return false;
  }

  private DirectoryContent ensureParentExists(TPath path) throws TIoException {
    TPath parent = path.parent();
    if (parent == null) {
      return new DirectoryContent();
    } else {
      if (!dirExists(parent)) {
        createDir(parent);
      }
      return getChildren(parent, createDirs);
    }
  }

  private void createDirImpl(TPath path) {
    createDirs.put(path, new DirectoryContent());
  }

  public TPath[] listDirs(TPath path) {
    return getChildren(path, createDirs).dirs();
  }

  public TPath[] listFiles(TPath path) {
    return getChildren(path, createDirs).files();
  }

  private DirectoryContent getChildren(TPath parent, Map collection) {
    return ((DirectoryContent) collection.get(parent));
  }

  public InputStream createInputStream(TPath path) throws TIoException {
    return retrieveFileContent(path).inputStream();
  }

  private FileContent retrieveFileContent(TPath path) throws TFileNotFoundException {
    FileContent content = fileContent(path);
    if (content == null) {
      throw new TFileNotFoundException(path);
    }
    return content;
  }

  private FileContent fileContent(TPath path) {
    return (FileContent) createFiles.get(path);
  }

  public OutputStream createOutputStream(TPath path, FileIo.Mode mode) throws TIoException {
    FileContent content = fileContent(path);
    if (content == null) {
      content = createFileInSystem(path);
    }
    return content.outputStream();
  }

  private FileContent createFileInSystem(TPath path) throws TIoException {
    if (dirExists(path)) {
      throw new TIoException(path, "exists as a directory");
    }
    getChildren(path.parent(), createDirs).addFile(path);
    FileContent fileContent = new FileContent();
    createFiles.put(path, fileContent);
    return fileContent;
  }

  public void deleteDirectory(TPath path) throws TIoException {
    if (!dirExists(path)) {
      throw new TDirectoryNotFoundException(path);
    }
    DirectoryContent directoryContent = getChildren(path, createDirs);
    if (!directoryContent.isEmpty()) {
      throw new TIoException(path, "Directory not empty");
    }
    createDirs.remove(path);
    getChildren(path.parent(), createDirs).removeDir(path);
  }

  public void moveFile(TPath source, TPath destination) throws TIoException {
    FileContent sourceFile = fileContent(source);
    FileContent destFile = createFileInSystem(destination);
    destFile.setContent(sourceFile.getContent());
    deleteFile(source);
  }

  public String pathString(TPath path) {
    return path.toPathString();
  }

  public long fileLength(TPath path) {
    return fileContent(path).content.size();
  }

  private static class DirectoryContent {
    private Map dirs = new HashMap();
    private Map files = new HashMap();

    public TPath[] dirs() {
      return (TPath[]) dirs.values().toArray(new TPath[dirs.size()]);
    }

    public void addDir(TPath directory) {
      dirs.put(directory.lastElementName(), directory);
    }

    public void addFile(TPath file) {
      files.put(file.lastElementName(), file);
    }

    public TPath[] files() {
      return (TPath[]) files.values().toArray(new TPath[files.size()]);
    }

    public boolean isEmpty() {
      return files.isEmpty() && dirs.isEmpty();
    }

    public void removeFile(TPath file) {
      files.remove(file.lastElementName());
    }

    public void removeDir(TPath directory) {
      dirs.remove(directory.lastElementName());
    }
  }

  private static class FileContent {
    private ByteArrayBuffer content = new ByteArrayBuffer();

    public void setContent(String content) {
      this.content = new ByteArrayBuffer(content.getBytes());
    }

    public String getContent() {
      return new String(content.toByteArray());
    }

    public OutputStream outputStream() {
      return new OutputStream() {

        public void write(int b) {
          content.append((byte) b);
        }
      };
    }

    public InputStream inputStream() {
      return new InputStream() {
        private int position = 0;

        public int read() {
          return (position == content.size()) ? -1 : content.byteAt(position++);
        }
      };
    }
  }


}
