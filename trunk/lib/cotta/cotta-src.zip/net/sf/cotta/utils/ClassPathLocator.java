package net.sf.cotta.utils;

import net.sf.cotta.*;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.StringTokenizer;

public class ClassPathLocator {
  public static final Resource NULL = new Resource() {
    public void close() {
    }
  };

  private Class clazz;

  public ClassPathLocator(Class clazz) {
    this.clazz = clazz;
  }

  public ClassPath locate() {
    URL url = getClass().getResource(resourcePathToClassFile());
    if ("jar".equalsIgnoreCase(url.getProtocol())) {
      return new ClassPath(getJarFileOnClassPath(url));
    } else {
      return new ClassPath(goToClassPathRootDirectory(url));
    }
  }

  private TDirectory goToClassPathRootDirectory(URL url) {
    TFile classFile = getClassFile(url);
    int level = new StringTokenizer(clazz.getName(), ".").countTokens();
    TDirectory directory = classFile.parent();
    for (int i = 0; i < level - 1; i++) {
      directory = directory.parent();
    }
    return directory;
  }

  private String resourcePathToClassFile() {
    return "/" + clazz.getName().replace('.', '/') + ".class";
  }

  private TFile getJarFileOnClassPath(URL url) {
    String file = url.getFile();
    int index = file.indexOf("!");
    if (index == -1) {
      throw new IllegalArgumentException(url.toExternalForm() + " does not have '!' for a Jar URL");
    }
    File fileObject = fromUri(file.substring(0, index));
    return new TFileFactory().file(fileObject.getAbsolutePath());
  }

  private File fromUri(String fileUri) {
    File fileObject = null;
    try {
      fileObject = new File(new URI(fileUri));
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't locate jar file:" + fileUri, e);
    }
    return fileObject;
  }

  private TFile getClassFile(URL url) {
    try {
      File file = new File(new URI(url.toExternalForm()));
      return new TFileFactory().file(file.getAbsolutePath());
    } catch (URISyntaxException e) {
      throw new RuntimeException("Couldn't convert URL to File:" + url, e);
    }
  }
}
