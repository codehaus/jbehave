package net.sf.cotta;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TFile {
  private TPath path;
  private FileSystem fileSystem;

  public TFile(FileSystem fileSystem, TPath path) {
    this.fileSystem = fileSystem;
    this.path = path;
  }

  public boolean exists() {
    return fileSystem.fileExists(path);
  }

  public TFile create() throws TIoException {
    parent().ensureExists();
    fileSystem.createFile(path);
    return this;
  }

  public String name() {
    return path.lastElementName();
  }

  public TDirectory parent() {
    return new TDirectory(fileSystem, path.parent());
  }

  public void delete() throws TIoException {
    fileSystem.deleteFile(path);
  }

  public FileIo io() {
    return new FileIo(fileSystem, path);
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final TFile tFile = (TFile) o;

    if (!fileSystem.equals(tFile.fileSystem)) return false;
    if (!path.equals(tFile.path)) return false;

    return true;
  }

  public int hashCode() {
    int result;
    result = path.hashCode();
    result = 29 * result + fileSystem.hashCode();
    return result;
  }

  public void copyTo(TFile target) throws TIoException {
    InputStream is = null;
    OutputStream os = null;
    try {
      is = io().inputStream();
      os = target.io().outputStream();
      FileIo.copy(is, os);
    } catch (IOException e) {
      throw new TIoException(target.path,
          "Error copying from <" + this.path.toPathString() + "> to <" + target.path.toPathString() + ">", e);
    } finally {
      closeInputStream(is);
      closeOutputStream(os);
    }

  }

  public void moveTo(TFile destination) throws TIoException {
    if (!exists()) {
      throw new TFileNotFoundException(path);
    }
    if (destination.exists()) {
      throw new TIoException(destination.path, "Destination exists");
    }
    if (fileSystem == destination.fileSystem || fileSystem.equals(destination.fileSystem)) {
      fileSystem.moveFile(this.path, destination.path);
    }
    else {
      this.copyTo(destination);
      delete();
    }
  }

  private void closeInputStream(InputStream is) {
    if (is != null) {
      try {
        is.close();
      } catch (IOException e) {

      }
    }
  }

  private void closeOutputStream(OutputStream os) {
    if (os != null) {
      try {
        os.close();
      } catch (IOException e) {

      }
    }
  }

  public String path() {
    return fileSystem.pathString(path);
  }

  public long length() {
    return fileSystem.fileLength(path);
  }

  public TFile ensureExists() throws TIoException {
    if (!exists()) {
      create();
    }
    return this;
  }
}