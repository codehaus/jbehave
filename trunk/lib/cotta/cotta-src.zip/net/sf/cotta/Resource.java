package net.sf.cotta;

public interface Resource {
  public void close() throws TIoException;
}
