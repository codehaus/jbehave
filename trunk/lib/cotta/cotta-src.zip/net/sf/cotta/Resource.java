package net.sf.cotta;

public interface Resource {
  public static final Resource NULL = new Resource() {
    public void close() {
    }
  };

  public void close() throws TIoException;
}
